-- FF League starter schema. Run in Supabase SQL Editor after creating your project.
create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'captain');
create type public.tournament_status as enum ('draft', 'registration_open', 'registration_closed', 'live', 'completed');
create type public.registration_status as enum ('pending', 'approved', 'rejected', 'waitlisted');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role public.app_role not null default 'captain',
  created_at timestamptz not null default now()
);
create table public.teams (
  id uuid primary key default gen_random_uuid(),
  captain_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  tag text not null,
  logo_url text,
  captain_ff_uid text not null,
  created_at timestamptz not null default now(),
  unique (captain_id, name),
  unique (tag)
);
create table public.players (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  in_game_name text not null,
  ff_uid text not null,
  is_substitute boolean not null default false,
  created_at timestamptz not null default now(),
  unique (ff_uid)
);
create table public.tournaments (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text not null default '',
  rules text not null default '',
  format text not null default 'Battle Royale',
  prize_pool numeric(12,2) not null default 0 check (prize_pool >= 0),
  currency text not null default 'BDT',
  max_teams integer not null default 48 check (max_teams > 0),
  registration_starts_at timestamptz,
  registration_ends_at timestamptz,
  starts_at timestamptz,
  status public.tournament_status not null default 'draft',
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);
create table public.registrations (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  team_id uuid not null references public.teams(id) on delete cascade,
  status public.registration_status not null default 'pending',
  group_name text,
  slot_number integer,
  admin_note text,
  created_at timestamptz not null default now(),
  unique (tournament_id, team_id),
  unique (tournament_id, slot_number)
);
create table public.matches (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  match_number integer not null,
  group_name text,
  scheduled_at timestamptz,
  room_id text,
  room_password text,
  room_published_at timestamptz,
  status text not null default 'scheduled' check (status in ('scheduled','live','completed')),
  created_at timestamptz not null default now(),
  unique (tournament_id, match_number, group_name)
);
create table public.match_results (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  team_id uuid not null references public.teams(id) on delete cascade,
  placement integer not null check (placement > 0),
  kills integer not null default 0 check (kills >= 0),
  placement_points integer not null default 0 check (placement_points >= 0),
  total_points integer generated always as (placement_points + kills) stored,
  admin_note text,
  updated_at timestamptz not null default now(),
  unique (match_id, team_id)
);
create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid references public.tournaments(id) on delete cascade,
  title text not null,
  body text not null,
  published boolean not null default false,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

-- Enable row-level security. Review policies carefully before production launch.
alter table public.profiles enable row level security;
alter table public.teams enable row level security;
alter table public.players enable row level security;
alter table public.tournaments enable row level security;
alter table public.registrations enable row level security;
alter table public.matches enable row level security;
alter table public.match_results enable row level security;
alter table public.announcements enable row level security;

-- Helper: never allow users to self-promote to admin. Assign admin role manually
-- from a trusted SQL/editor session only.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') $$;

create policy "Public can read tournaments" on public.tournaments for select using (status <> 'draft' or public.is_admin());
create policy "Admins manage tournaments" on public.tournaments for all using (public.is_admin()) with check (public.is_admin());
create policy "Users read own profile" on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "Users update own display name" on public.profiles for update using (id = auth.uid() and role = 'captain') with check (id = auth.uid() and role = 'captain');
create policy "Admins manage profiles" on public.profiles for all using (public.is_admin()) with check (public.is_admin());
create policy "Public read teams" on public.teams for select using (true);
create policy "Captains create own teams" on public.teams for insert with check (captain_id = auth.uid());
create policy "Captains update own teams" on public.teams for update using (captain_id = auth.uid() or public.is_admin()) with check (captain_id = auth.uid() or public.is_admin());
create policy "Captains delete own teams" on public.teams for delete using (captain_id = auth.uid() or public.is_admin());
create policy "Public read player rosters" on public.players for select using (true);
create policy "Team captains manage roster" on public.players for all using (exists (select 1 from public.teams t where t.id = team_id and t.captain_id = auth.uid()) or public.is_admin()) with check (exists (select 1 from public.teams t where t.id = team_id and t.captain_id = auth.uid()) or public.is_admin());
create policy "Public read approved registrations" on public.registrations for select using (status = 'approved' or exists (select 1 from public.teams t where t.id = team_id and t.captain_id = auth.uid()) or public.is_admin());
create policy "Captains submit registration" on public.registrations for insert with check (exists (select 1 from public.teams t where t.id = team_id and t.captain_id = auth.uid()) and status = 'pending');
create policy "Admins manage registrations" on public.registrations for all using (public.is_admin()) with check (public.is_admin());
create policy "Public read matches without room secrets" on public.matches for select using (status <> 'draft' or public.is_admin());
create policy "Admins manage matches" on public.matches for all using (public.is_admin()) with check (public.is_admin());
create policy "Public read match results" on public.match_results for select using (true);
create policy "Admins manage results" on public.match_results for all using (public.is_admin()) with check (public.is_admin());
create policy "Public read published announcements" on public.announcements for select using (published or public.is_admin());
create policy "Admins manage announcements" on public.announcements for all using (public.is_admin()) with check (public.is_admin());

-- IMPORTANT SECURITY NOTE:
-- Do not expose room passwords through the public matches table. Before production,
-- move room_id/password into a separate protected table and add policies so only
-- approved captains for that tournament and admins can read them.
